# Cloud Cost & Usage Dashboard

Simple Streamlit app with simulated cloud usage, cost charts and a cost estimator.

## Run locally
    pip install -r requirements.txt
    streamlit run app.py

## Run with Docker
    docker build -t cloud-dashboard .
    docker run -p 8501:8501 cloud-dashboard
    # open http://localhost:8501

## Deploy on Streamlit Community Cloud
1. Push this folder to a GitHub repo
2. Go to share.streamlit.io -> New app
3. Pick the repo, branch `main`, main file `app.py` -> Deploy
