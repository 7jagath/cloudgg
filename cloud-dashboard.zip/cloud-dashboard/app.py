import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Cloud Cost & Usage Dashboard", page_icon="☁️", layout="wide")
st.title("☁️ Cloud Cost & Usage Dashboard")
st.caption("Simulated cloud data - a simple demo project")

# ---------- Sidebar ----------
st.sidebar.header("Settings")
provider = st.sidebar.selectbox("Cloud provider", ["AWS", "Azure", "GCP"])
days = st.sidebar.slider("Days of data", 7, 90, 30)
seed = st.sidebar.number_input("Random seed", value=42, step=1)

# ---------- Simulated data ----------
rng = np.random.default_rng(int(seed))
dates = pd.date_range(end=pd.Timestamp.today().normalize(), periods=days)
services = ["Compute", "Storage", "Database", "Network"]
base_cost = {"Compute": 40, "Storage": 15, "Database": 30, "Network": 10}

cost_df = pd.DataFrame(
    {s: base_cost[s] + rng.normal(0, base_cost[s] * 0.15, days).cumsum() * 0.1 + rng.random(days) * 5
     for s in services},
    index=dates,
).clip(lower=1)

usage_df = pd.DataFrame(
    {"CPU %": np.clip(rng.normal(55, 15, days), 5, 100),
     "Memory %": np.clip(rng.normal(65, 10, days), 10, 100)},
    index=dates,
)

# ---------- KPIs ----------
total = cost_df.sum().sum()
c1, c2, c3 = st.columns(3)
c1.metric(f"{provider} total cost", f"${total:,.0f}")
c2.metric("Avg CPU", f"{usage_df['CPU %'].mean():.1f}%")
c3.metric("Avg Memory", f"{usage_df['Memory %'].mean():.1f}%")

# ---------- Charts ----------
left, right = st.columns(2)
with left:
    st.subheader("Daily cost by service ($)")
    st.area_chart(cost_df)
with right:
    st.subheader("Resource utilization")
    st.line_chart(usage_df)

st.subheader("Cost share by service")
st.bar_chart(cost_df.sum())

# ---------- Cost estimator ----------
st.divider()
st.subheader("🧮 Monthly cost estimator")
e1, e2, e3 = st.columns(3)
vms = e1.number_input("Virtual machines", 0, 100, 3)
storage_gb = e2.number_input("Storage (GB)", 0, 100000, 500)
egress_gb = e3.number_input("Data transfer out (GB)", 0, 100000, 100)

# Illustrative rates only, not real provider pricing
estimate = vms * 0.05 * 730 + storage_gb * 0.023 + egress_gb * 0.09
st.success(f"Estimated monthly cost: **${estimate:,.2f}**")
st.caption("Rates are illustrative, not real provider pricing.")

with st.expander("View raw data"):
    st.dataframe(cost_df.join(usage_df).round(2))
